#include "iostream"
#include "conio.h"
#include "string.h"
#include "iomanip"
#include "fstream"
//#include "process.h"
using namespace std;
const int TRUE = 1;
const int FALSE = 0;

struct phoneBook
{
 char name[15],addr[15],phone[12];
};

struct Linked_List
{
 struct phoneBook ph;
 struct Linked_List *next;
};

typedef struct Linked_List node;

node *head = NULL,*New;

void initialize(node *N)
{
 cout << "\n\t\t\tName : ";
 cin >> N -> ph.name;
 cout << "\n\t\t\tAddress : ";
 cin >> N -> ph.addr;
 cout << "\n\t\t\tPhone No. : ";
 cin >> N -> ph.phone;
}

int empty(node *n)
{
 if(strcmp(n -> ph.name,"") == 0 && strcmp(n -> ph.addr,"") == 0 && strcmp(n -> ph.name,"") == 0)
  return 1;
 else
  return 0;
}

void create()
{
 New = new node;
 strcpy(New -> ph.name,"");
 strcpy(New -> ph.addr,"");
 strcpy(New -> ph.phone,"");
 New -> next = NULL;
 if(head == NULL)
  head = New;
}

int insert()
{
 ofstream outfile;
 outfile.open("d:\\Dbase.txt",ios::app);
 if(outfile.fail())
  {
   cout << "Error : Couldn't open file.";
   getch();
//   exit(0);
  }

 if(head == NULL)
  create();

 if(head -> next == NULL)
  if(empty(head))
     {
    initialize(New);
      outfile.write((char *) &head,sizeof(head));
      return 1;
     }

 char ntmp[15];
 create();
 initialize(New);
 strcpy(ntmp,New -> ph.name);
 node *temp = head,*loc = head;
 if(strcmpi(ntmp,head -> ph.name) < 0)
 {
   New -> next = head;
   head = New;
 }

 else
  {
    while(temp -> next != NULL)
     {
       temp = temp -> next;
       if(strcmpi(ntmp,temp -> ph.name) > 0)
        loc = temp;
      }

    New -> next = loc -> next;
    loc -> next = New;
   }
 return 1;
}

void search(char *n)
{
 node *temp = head;
 int found = FALSE;

 if(head == NULL)
   found = FALSE;

 else if(strcmp(n,temp -> ph.name) == 0)
  found = TRUE;

 else
 {
  while(temp -> next != NULL)
  {
    temp = temp -> next;
    if(strcmp(n,temp -> ph.name) == 0)
     {
       found = TRUE;
       break;
      }
   }
  }

 if(found)
  {
    cout << "\n\n\t\t  Name : " << temp -> ph.name;
    cout << "\n\t\t  Address : " << temp -> ph.addr;
    cout << "\n\t\t  Phone NO. : " << temp -> ph.phone;
   }

 else
  {
    cout << "\n\n" << setw(44) << "Data not found";
    cout << "\n" << setw(53) << "Press any key to continue...";
   }
}


int remove(char *n)
{
 if(head == NULL)
    return 0;

 node *temp = head,*loc = head;
 if(strcmp(n,temp -> ph.name) == 0)
    {
     if(temp -> next == NULL)
       {
        head = NULL;
        delete temp;
       }

     else
       {
        head = temp -> next;
        delete temp;
       }
     return 1;
      }

 else
  {
    while(temp -> next != NULL)
     {
       temp = temp -> next;
       if(temp == NULL)
        return 0;

       if(strcmpi(n,temp -> ph.name) == 0)
        {
        if(temp -> next != NULL)
          {
            temp = loc -> next;
       loc -> next = temp -> next;
       delete temp;
          }
         else
           loc -> next = NULL;

         return 1;
        }

       loc = loc -> next;
      }
  }
 return 0;
}

int modify(char *n)
{
 node *temp = head;
 if(head == NULL)
  return 0;

 if(strcmpi(n,temp -> ph.name) == 0)
  {
    cout << "\n\n\t\t\t***** Previous Data *****";
    cout << "\n\t\t\t  Name : " << temp -> ph.name;
    cout << "\n\t\t\t  Address : " << temp -> ph.addr;
    cout << "\n\t\t\t  Phone NO. : " << temp -> ph.phone;
    cout << "\n\n\t\t\t***** Enter New Data *****\n";
    initialize(head);
    return 1;
   }

 else
 {
  while(temp -> next != NULL)
  {
    temp = temp -> next;
    if(temp == NULL)
     return 0;

    if(strcmpi(n,temp -> ph.name) == 0)
     {
       cout << "\n\n\t\t\t***** Previous Data *****";
       cout << "\n\t\t\t  Name : " << temp -> ph.name;
    cout << "\n\t\t\t  Address : " << temp -> ph.addr;
     cout << "\n\t\t\t  Phone NO. : " << temp -> ph.phone;
       cout << "\n\n\t\t\t***** Enter New Data *****\n";
   initialize(temp);
   return 1;
      }
    }
  }
 return 0;
}

void display()
{
 node *temp = head;
 if(head == NULL)
  {
   cout << "\n\n" << setw(46) << "Database is empty";
   cout << "\n" << setw(53) << "Press any key to continue...";
   return;
  }

 if(!empty(head))
  {
   cout << "\n\n\t\t  Name : " << temp -> ph.name;
   cout << "\n\t\t  Address : " << temp -> ph.addr;
   cout << "\n\t\t  Phone NO. : " << temp -> ph.phone << endl << endl;
  }

 while(temp -> next != NULL)
  {
    temp = temp -> next;
    cout << "\n\t\t  Name : " << temp -> ph.name;
  cout << "\n\t\t  Address : " << temp -> ph.addr;
  cout << "\n\t\t  Phone NO. : " << temp -> ph.phone << endl;
   }
}

int menu()
{
 cout << "\n\t\t      **********************************" << endl;
 cout << "\t\t      *     ----------------------     *" << endl;
 cout << "\t\t      *        TELEPHONE DIARY         *" << endl;
 cout << "\t\t      *     ----------------------     *" << endl;
 cout << "\t\t      **********************************" << endl << endl;
 cout << "\t\t      -----------------------------------" << endl;
 cout << "\t\t\t1. Add\n";
 cout << "\t\t\t2. Search\n";
 cout << "\t\t\t3. Delete\n";
 cout << "\t\t\t4. Modify\n";
 cout << "\t\t\t5. View\n";
 cout << "\t\t\t0. Exit\n";
 cout << "\t\t      -----------------------------------" << endl << endl;

 int choice;
 cout << setw(45) << "Enter Choice : ";
 cin >> choice;
 return choice;
}

int main()
{
 char name[15];
  do
 {
//  clrscr();
  int choice = menu();
  int success;
  cout << "\n\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  switch(choice)
   {
    case 1:
      success = insert();
         if(success)
            cout << "\n\n\n" << setw(51) << "Data Inserted Successfully";

         cout << "\n" << setw(53) << "Press any key to continue...";
         break;

    case 2:
       cout << "\n\t\t\tEnter Name : ";
         cin >> name;
       search(name);
      break;

    case 3:
      cout << "\n\t\t\tEnter Name : ";
         cin >> name;
         success = remove(name);
         if(success)
           cout << "\n\n\n" << setw(50) << "Data Deleted Successfully";
         else
           cout << "\n\n" << setw(48) << "Data Doesn't Exists";

         cout << "\n" << setw(53) << "Press any key to continue...";
      break;

    case 4:
      cout << "\n\t\t\tEnter Name : ";
         cin >> name;
         success = modify(name);
         if(success)
           cout << "\n\n\n" << setw(50) << "Data Modified Successfully";
         else
           cout << "\n\n" << setw(48) << "Data Doesn't Exists";

         cout << "\n" << setw(53) << "Press any key to continue...";
      break;

    case 5:
      display();
         break;

    case 0:
//      clrscr();
         cout << "\n\n\n\n\n\n\n\n";
         cout << setw(46) << "TELEPHONE DIARY\n";
         cout << setw(47) << "(Using Linked List)";
         cout << "\n\n\n\n\n" << setw(51) << "Press any key to halt...";
         getch();
      return 0;

    default:
         cout << endl << setw(58) << "Please select appropriate option\n";
         cout << setw(55) << "Press any key to continue...";
   }

  getch();
 }while(1);
}

